newFunction();

function newFunction() {
    console.log(new Date());
}
